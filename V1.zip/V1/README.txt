Esta el dise�o de la base de datos, no dise�e autor y categoria como atributo ya que estan encierran varios libros de la forma relacional,
esta la busqueda por cada atributo del libro, falta dise�ar la busqueda por api de google y por ultimo se puede eliminar el libro deseado
falta introducir el libro que se encuentra del la busqueda de la api de google. 